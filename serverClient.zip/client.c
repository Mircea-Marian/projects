#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define BUFF_DIM 4096
#define CHUNK_BUFF_DIM 512

void sendOverTCP( char * mes , int client , const int totalToSend){
    int alreadySent = 0, sent;

    while( alreadySent < totalToSend ){
        sent = write( client , mes + alreadySent, totalToSend - alreadySent );
        if( sent < 0 ) {printf("error\n");return;}
        alreadySent += sent;
    }
}

int readFrom( char *buffer , int clientSocket ){

    char chunkBuffer[CHUNK_BUFF_DIM];

    int totalRead = 0;

    int receivedBytesNo = read( clientSocket , chunkBuffer , CHUNK_BUFF_DIM );

    memcpy( buffer , chunkBuffer , sizeof(char) *  receivedBytesNo );

    totalRead += receivedBytesNo;

    while( receivedBytesNo == CHUNK_BUFF_DIM && totalRead + CHUNK_BUFF_DIM <= BUFF_DIM ) {

        receivedBytesNo = read( clientSocket , chunkBuffer , CHUNK_BUFF_DIM );

        memcpy( buffer + totalRead , chunkBuffer , sizeof(char) *  receivedBytesNo );

        totalRead += receivedBytesNo;
    }

    return totalRead;
}

void main(int argc, char *argv[]) {
   int sockfd, portno, n;
   struct sockaddr_in serv_addr;
   struct hostent *server;

   char buffer[4096];

   if (argc < 3) {
      fprintf(stderr,"usage %s hostname port\n", argv[0]);
      exit(0);
   }

   portno = atoi(argv[2]);

   /* Create a socket point */
   sockfd = socket(AF_INET, SOCK_STREAM, 0);

   if (sockfd < 0) {
      perror("ERROR opening socket");
      exit(1);
   }

   inet_aton(argv[1], &serv_addr.sin_addr);

   bzero((char *) &serv_addr, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_port = htons(portno);

   /* Now connect to the server */
   if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
      perror("ERROR connecting");
      exit(1);
   }

   /* Now ask for a message from the user, this message
      * will be read by servers
   */

   fd_set readFDS, tmpFDS;
    FD_ZERO(&readFDS);
    FD_ZERO(&tmpFDS);
    FD_SET(0,&readFDS);
    FD_SET(sockfd,&readFDS);
    while(1){
        tmpFDS = readFDS;
        if( select(sockfd + 1, &tmpFDS, NULL, NULL, NULL) < 0 ){
            printf("Error: select error !");
            return;
        }
        if( FD_ISSET(0,&tmpFDS) ){
            
            //citire de la consola
            fgets(buffer,4095,stdin);
            buffer[4095] = '\0';

            if( !strncmp("quit" , buffer, 4) ){
                sendOverTCP(buffer, sockfd, strlen(buffer) );
                break;
            } else if( !strncmp("send",buffer,4) ){
                printf("Please write the name of the file u want to send, then hit \"Enter\".\n");
                bzero(&buffer, 4096);
                scanf("%s",buffer);

                sendOverTCP( buffer , sockfd , strlen(buffer) );

                FILE *toSend = fopen(buffer,"rt");
                if( toSend == NULL ){printf("Can't open file !\n"); break;}

                while( fgets( buffer , BUFF_DIM , toSend ) != NULL ){
                  sendOverTCP(buffer , sockfd , strlen(buffer));
                }
                close(toSend);
            } else
              sendOverTCP(buffer, sockfd, strlen(buffer) );
        }
        if( FD_ISSET(sockfd,&tmpFDS) ){
            int receivedNo = readFrom( buffer , sockfd );
            if( receivedNo == BUFF_DIM ) {
              char c = buffer[BUFF_DIM - 1];
              buffer[BUFF_DIM-1] = '\0';
              printf("received from %d: <%s%c>\n", sockfd , buffer , c);
            } else if( receivedNo == 4 && !strncmp("quit" , buffer , 4 )) {
              break;
            } else {
              buffer[receivedNo] = '\0';
              printf("received from %d: <%s>\n", sockfd , buffer);
            }
        }
    }
    close(sockfd);
}