#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <limits.h>
#include <dirent.h>
#include <sys/stat.h>
#define BUFF_DIM 4096
#define CHUNK_BUFF_DIM 512

void sendOverTCP( char * mes , int client , const int totalToSend){
    int alreadySent = 0, sent;

    while( alreadySent < totalToSend ){
        sent = write( client , mes + alreadySent, totalToSend - alreadySent );
        if( sent < 0 ) {printf("error\n");return;}
        alreadySent += sent;
    }
}

int readFrom( char *buffer , int clientSocket ){

    char chunkBuffer[CHUNK_BUFF_DIM];

    int totalRead = 0;

    int receivedBytesNo = read( clientSocket , chunkBuffer , CHUNK_BUFF_DIM );

    memcpy( buffer , chunkBuffer , sizeof(char) *  receivedBytesNo );

    totalRead += receivedBytesNo;

    while( receivedBytesNo == CHUNK_BUFF_DIM && totalRead + CHUNK_BUFF_DIM <= BUFF_DIM ) {

        receivedBytesNo = read( clientSocket , chunkBuffer , CHUNK_BUFF_DIM );

        memcpy( buffer + totalRead , chunkBuffer , sizeof(char) *  receivedBytesNo );

        totalRead += receivedBytesNo;
    }

    return totalRead;
}

int main( int argc, char *argv[] ) {
   int sockfd, newsockfd, clilen;
   char buffer[4096];
   struct sockaddr_in serv_addr, cli_addr;
   int  n,i;

   /* First call to socket() function */
   sockfd = socket(AF_INET, SOCK_STREAM, 0);

   if (sockfd < 0) {
      perror("ERROR opening socket");
      exit(1);
   }

   /* Initialize socket structure */
   bzero((char *) &serv_addr, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_addr.s_addr = INADDR_ANY;
   serv_addr.sin_port = htons(atoi( argv[1] ) );

   /* Now bind the host address using bind() call.*/
   if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
      perror("ERROR on binding");
      exit(1);
   }

   /* Now start listening for the clients, here process will
      * go in sleep mode and will wait for the incoming connection
   */

   listen(sockfd,5);
   clilen = sizeof(cli_addr);

    fd_set readFDS,tmpFDS;
    FD_ZERO(&readFDS);
    FD_SET(sockfd, &readFDS);
    FD_SET(0,&readFDS);
    FD_ZERO(&tmpFDS);

    unsigned char isRunning = 1;
    int rez;
    char flags;

    while( isRunning ) {
        tmpFDS = readFDS;
        select( FD_SETSIZE , &tmpFDS ,  NULL , NULL, NULL );
        if( FD_ISSET(0, &tmpFDS) ){
            bzero(buffer, 4096);
            scanf( "%s" , buffer );
            if( !strncmp("quit" , buffer, 4) ){
                isRunning = 0;
                for( i = 1 ; i < FD_SETSIZE ; i++ )
                    if( FD_ISSET(i,&readFDS) && i != sockfd ){
                        sendOverTCP( buffer , i , strlen( buffer ) );
                    }
            }
        }
        if( isRunning ){
            for( i  = 1 ; i < FD_SETSIZE ; i++ )
                if( FD_ISSET( i , &tmpFDS ) ){
                        if( i == sockfd ){
                            rez = accept(sockfd, (struct sockaddr *)(&cli_addr), &clilen);
                            if( rez < 0 ){
                                printf("Error: Accept error !\n");
                                return;
                            }
                            FD_SET(rez,&readFDS);
                        }
                        else {
                            int receivedNo = readFrom( buffer , i );
                            
                            if( !strncmp("quit" , buffer , 4 )){
                                FD_CLR( i , &readFDS );
                            }

                            if( receivedNo == BUFF_DIM ) {
                                char c = buffer[BUFF_DIM - 1];
                                buffer[BUFF_DIM-1] = '\0';
                                printf("line 122 received from %d: <%s%c>\n", i , buffer , c);
                            } else {
                                buffer[receivedNo] = '\0';
                                printf("line 125 received from %d: <%s>\n", i , buffer);
                            }
                        }
                }
        }
    }
    close(sockfd);
}
